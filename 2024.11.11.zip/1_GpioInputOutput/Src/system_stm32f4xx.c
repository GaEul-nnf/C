#include <stdint.h>


uint32_t SystemCoreClock = 16000000;
